<?php

    require_once '../global.php';
    header('Location: ' . $ADMIN_URL . '/analytics/?chart');

?>