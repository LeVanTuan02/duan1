        <!-- CONTENT -->
        <div class="content">
            <section class="content__thankyou grid">
                <h2 class="content__thankyou-title">Đã đặt hàng thành công</h2>
                <p class="content__thankyou-desc">Cảm ơn bạn đã đặt hàng của Tea House.
                    Nhân viên sẽ gọi điện từ số điện thoại bạn đã cung cấp
                    để Confirm (Xác nhận) lại với bạn trong thời gian sớm nhất để xác nhận đơn hàng.</p>
            </section>
        </div>
        <!-- END CONTENT -->