<?php

    require_once '../global.php';
    header('Location: ' . $SITE_URL . '/home');

?>