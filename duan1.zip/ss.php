<?php

    require_once 'global.php';
    require_once 'dao/user.php';

    echo "<pre>";
    var_dump($_SESSION['user']);


    // unset($_SESSION['cart']);


?>